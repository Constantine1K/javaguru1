package lesson4.Stock;

public class StockTest {
    public static void main(String[] args) {
        Stock stock = new Stock("IBM", 164);
        stock.updatePrice(10);
        stock.updatePrice(100);
        stock.updatePrice(200);
        stock.getCurrentValue();





    }
}
